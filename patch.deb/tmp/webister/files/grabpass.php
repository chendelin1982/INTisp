<?php

/*
 * Adaclare Technologies
 *
 * Webister Hosting Software
 *
 *
 */

include '/var/webister/interface/config.php';
echo $pass;
